(function(){
  chrome.runtime.onMessage.addListener((m,s,r)=>{
    if(m.type==="content-ping") r({alive:true});
  });

  let mode=null, box=null, label=null, fixedHidden=[];

  function overlay(){
    if(!box){
      box=document.createElement("div");
      Object.assign(box.style,{
        position:"fixed",pointerEvents:"none",zIndex:2147483647,
        border:"1px solid rgba(129,140,248,0.7)",
        borderRadius:"10px",
        background:"rgba(255,255,255,0.05)",
        backdropFilter:"blur(2px)"
      });
      document.body.appendChild(box);
    }
    if(!label){
      label=document.createElement("div");
      Object.assign(label.style,{
        position:"fixed",pointerEvents:"none",
        background:"rgba(0,0,0,0.7)",
        color:"#fff",padding:"3px 6px",
        borderRadius:"6px",fontSize:"11px",
        zIndex:2147483647
      });
      document.body.appendChild(label);
    }
  }
  function clearOverlay(){
    box?.remove(); label?.remove(); box=null; label=null;
  }

  function isInteractive(el){
    if(!el||el.nodeType!==1) return false;
    const t=el.tagName, r=el.getAttribute("role");
    return t==="A"||t==="BUTTON"||t==="INPUT"||el.onclick||(r&&r.toLowerCase()==="button");
  }

  function findElement(el){
    let n=el;
    while(n&&n!==document.body){
      const r=n.getBoundingClientRect();
      if(r.width>20 && r.height>20) return n;
      n=n.parentElement;
    }
    return el;
  }

  function findBlock(el){
    if(el===document.body||el===document.documentElement) return el;
    let rootInteractive=isInteractive(el);
    let n=el,best=null;
    while(n&&n!==document.body){
      const r=n.getBoundingClientRect();
      const style=getComputedStyle(n);
      const tag=n.tagName;
      if(tag==="BODY"||tag==="HTML") break;
      const widthOk=r.width>80;
      const heightOk=r.height>40;
      const hasImg=n.querySelector("img,video,picture");
      const hasText=n.querySelector("h1,h2,h3,h4,h5,h6,p,span");

      let score=(widthOk?2:0)+(heightOk?1:0)+(hasImg?2:0)+(hasText?1:0);
      if(rootInteractive && (tag==="NAV"||tag==="HEADER")) score=-999;
      if(score>=3) best=n;
      n=n.parentElement;
    }
    return best||el;
  }

  async function captureVisible(){
    return await new Promise(res=>{
      chrome.runtime.sendMessage({type:"capture-visible"},resp=>res(resp));
    });
  }
  async function loadImg(u){return await new Promise(r=>{let i=new Image();i.onload=()=>r(i);i.src=u;});}

  async function captureElementFull(el){
    // scroll so element's top enters viewport
    const rect0=el.getBoundingClientRect();
    window.scrollTo(window.scrollX, rect0.top+window.scrollY-40);
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    const rect=el.getBoundingClientRect();
    const dpr=window.devicePixelRatio||1;
    const resp=await captureVisible();
    if(!resp||!resp.success) return;
    const img=await loadImg(resp.screenshot);
    const c=document.createElement("canvas");
    c.width=rect.width*dpr;
    c.height=rect.height*dpr;
    const ctx=c.getContext("2d");
    ctx.drawImage(img,
      rect.left*dpr, rect.top*dpr, rect.width*dpr, rect.height*dpr,
      0,0,rect.width*dpr,rect.height*dpr
    );
    chrome.runtime.sendMessage({
      type:"save-image",
      fileName:"element-"+Date.now()+".png",
      dataUrl:c.toDataURL("image/png")
    });
  }

  function hideFixed(){
    fixedHidden=[];
    const all=document.body.getElementsByTagName("*");
    for(let el of all){
      const st=getComputedStyle(el);
      if(st.position==="fixed" || st.position==="sticky"){
        fixedHidden.push({el, vis:el.style.visibility});
        el.style.visibility="hidden";
      }
    }
  }
  function restoreFixed(){
    fixedHidden.forEach(x=>{x.el.style.visibility=x.vis;});
    fixedHidden=[];
  }

  async function captureFullPage(){
    const dpr=window.devicePixelRatio||1;
    const origY=window.scrollY, origX=window.scrollX;
    const doc=document.documentElement;
    const totalHeight=doc.scrollHeight;
    const width=doc.clientWidth;

    hideFixed();

    const vh=window.innerHeight, overlap=80;
    let y=0;
    const parts=[];
    while(y<totalHeight){
      window.scrollTo(origX,y);
      await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
      const resp=await captureVisible(); if(!resp||!resp.success) break;
      const img=await loadImg(resp.screenshot);
      const chunkStart=y;
      const chunkEnd=Math.min(y+vh,totalHeight);
      const ch=chunkEnd-chunkStart;
      parts.push({img,chunkStart,ch});
      if(y+vh>=totalHeight) break;
      y+=vh-overlap;
    }
    window.scrollTo(origX,origY);
    restoreFixed();
    if(!parts.length) return;

    const cv=document.createElement("canvas");
    cv.width=width*dpr; cv.height=totalHeight*dpr;
    const ctx=cv.getContext("2d");

    for(const p of parts){
      ctx.drawImage(
        p.img,
        0, (p.chunkStart-window.scrollY)*dpr, width*dpr, p.ch*dpr,
        0, p.chunkStart*dpr, width*dpr, p.ch*dpr
      );
    }

    chrome.runtime.sendMessage({
      type:"save-image",
      fileName:"page-"+Date.now()+".png",
      dataUrl:cv.toDataURL("image/png")
    });
  }

  async function captureBlockFull(block){
    const dpr=window.devicePixelRatio||1;
    const origY=window.scrollY, origX=window.scrollX;
    const f=block.getBoundingClientRect();
    const top=f.top+origY, left=f.left+origX;
    const w=f.width, h=f.height;
    const vh=window.innerHeight, overlap=80;
    let y=top;
    const parts=[];
    while(y<top+h){
      window.scrollTo(origX,y);
      await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
      const resp=await captureVisible(); if(!resp||!resp.success) break;
      const img=await loadImg(resp.screenshot);
      const chunkStart=Math.max(top,y);
      const chunkEnd=Math.min(top+h,y+vh);
      const ch=chunkEnd-chunkStart;
      const offsetVP=chunkStart-y;
      parts.push({img,offsetVP,ch,y});
      if(y+vh>=top+h) break;
      y+=vh-overlap;
    }
    window.scrollTo(origX,origY);
    if(!parts.length) return;

    const cv=document.createElement("canvas");
    cv.width=w*dpr; cv.height=h*dpr;
    const ctx=cv.getContext("2d");

    for(const p of parts){
      const chunkStart=Math.max(top,p.y);
      const offsetY=(chunkStart-top)*dpr;
      ctx.drawImage(
        p.img,
        (left-origX)*dpr, p.offsetVP*dpr, w*dpr, p.ch*dpr,
        0, offsetY, w*dpr, p.ch*dpr
      );
    }

    chrome.runtime.sendMessage({
      type:"save-image",
      fileName:"block-"+Date.now()+".png",
      dataUrl:cv.toDataURL("image/png")
    });
  }

  function move(e){
    if(!mode) return;
    overlay();
    let target;
    if(mode==="element") target=findElement(e.target);
    else target=findBlock(e.target);
    const r=target.getBoundingClientRect();
    box.style.left=r.left+"px"; box.style.top=r.top+"px";
    box.style.width=r.width+"px"; box.style.height=r.height+"px";
    label.textContent=`${Math.round(r.width)}×${Math.round(r.height)}`;
    label.style.left=r.left+"px"; label.style.top=(r.top-24)+"px";
  }

  function click(e){
    if(!mode) return;
    e.preventDefault(); e.stopPropagation();
    const currentMode=mode;
    mode=null;
    document.removeEventListener("mousemove",move,true);
    document.removeEventListener("click",click,true);
    clearOverlay();

    if(currentMode==="element"){
      const el=findElement(e.target);
      captureElementFull(el);
    }else if(currentMode==="page"){
      const block=findBlock(e.target);
      // если блок == body или почти весь экран по высоте => скрин всей страницы
      if(block===document.body || block===document.documentElement){
        captureFullPage();
      }else{
        const r=block.getBoundingClientRect();
        const docH=document.documentElement.scrollHeight;
        if(r.height>window.innerHeight*1.5 || r.height>docH*0.8){
          captureFullPage();
        }else{
          captureBlockFull(block);
        }
      }
    }
  }

  chrome.runtime.onMessage.addListener((m)=>{
    if(m.type==="capture-element"){
      mode="element";
      overlay();
      document.addEventListener("mousemove",move,true);
      document.addEventListener("click",click,true);
    }
    if(m.type==="start-page-or-block"){
      mode="page";
      overlay();
      document.addEventListener("mousemove",move,true);
      document.addEventListener("click",click,true);
    }
  });
})();