document.addEventListener("DOMContentLoaded", () => {
  function check(tabId, cb){
    chrome.tabs.sendMessage(tabId,{type:"content-ping"},(resp)=>{
      if(chrome.runtime.lastError||!resp) cb(false); else cb(true);
    });
  }
  function send(tabId,msg){
    check(tabId,(ok)=>{
      if(!ok){ alert("Контент-скрипт недоступен на этой вкладке."); return; }
      chrome.tabs.sendMessage(tabId,msg);
      window.close();
    });
  }
  chrome.tabs.query({active:true,currentWindow:true},tabs=>{
    const tab=tabs[0];
    document.getElementById("elementBtn").onclick=()=>send(tab.id,{type:"capture-element"});
    document.getElementById("pageBtn").onclick=()=>send(tab.id,{type:"start-page-or-block"});
  });
});