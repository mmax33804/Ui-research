chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "capture-visible") {
    const windowId = sender && sender.tab ? sender.tab.windowId : undefined;
    chrome.tabs.captureVisibleTab(windowId, { format: "png" }, img => {
      if (!img) {
        sendResponse({ success: false });
        return;
      }
      sendResponse({ success: true, screenshot: img });
    });
    return true;
  }

  if (msg.type === "save-image") {
    chrome.downloads.download({
      url: msg.dataUrl,
      filename: "UI-Searcher/" + msg.fileName
    });
  }
});