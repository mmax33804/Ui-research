(function(){
  // ping for popup
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
    if (msg.type === "ping") {
      sendResponse({alive:true});
    }
  });

  let mode = null;
  let frame = null;
  let handles = [];
  let styleEl = null;

  function ensureStyle(){
    if (styleEl) return;
    styleEl = document.createElement("style");
    styleEl.textContent = `
@keyframes uiSearcherDash {
  from { background-position: 0 0, 0 100%, 0 0, 100% 0; }
  to   { background-position: 8px 0, -8px 100%, 0 -8px, 100% 8px; }
}
.ui-searcher-frame {
  position:fixed;
  pointer-events:none;
  z-index:2147483647;
  border-radius:4px;
  box-sizing:border-box;
  background:
    linear-gradient(90deg,#007aff 50%,transparent 0) top left/8px 1px repeat-x,
    linear-gradient(90deg,#007aff 50%,transparent 0) bottom left/8px 1px repeat-x,
    linear-gradient(0deg,#007aff 50%,transparent 0) top left/1px 8px repeat-y,
    linear-gradient(0deg,#007aff 50%,transparent 0) top right/1px 8px repeat-y;
  animation: uiSearcherDash 500ms linear infinite;
}
.ui-searcher-handle {
  width:6px;
  height:6px;
  border-radius:999px;
  background:#007aff;
  box-shadow:0 0 0 1px #ffffff;
  position:fixed;
  pointer-events:none;
  z-index:2147483647;
}
.ui-searcher-size {
  position:fixed;
  pointer-events:none;
  z-index:2147483647;
  padding:2px 6px;
  border-radius:999px;
  background:rgba(15,23,42,0.92);
  color:#e5e7eb;
  font-size:11px;
  font-family:system-ui,-apple-system,"SF Pro Text",sans-serif;
}
    `;
    document.head.appendChild(styleEl);
  }

  let sizeLabel = null;
  function ensureSizeLabel(){
    if (sizeLabel) return;
    sizeLabel = document.createElement("div");
    sizeLabel.className = "ui-searcher-size";
    document.body.appendChild(sizeLabel);
  }

  function createFrame(rect){
    ensureStyle();
    if (!frame) {
      frame = document.createElement("div");
      frame.className = "ui-searcher-frame";
      document.body.appendChild(frame);
    }
    frame.style.left = rect.left + "px";
    frame.style.top = rect.top + "px";
    frame.style.width = rect.width + "px";
    frame.style.height = rect.height + "px";

    if (handles.length === 0) {
      for (let i=0;i<8;i++){
        const h = document.createElement("div");
        h.className = "ui-searcher-handle";
        document.body.appendChild(h);
        handles.push(h);
      }
    }
    const pts = [
      [rect.left, rect.top],
      [rect.left + rect.width/2, rect.top],
      [rect.left + rect.width, rect.top],
      [rect.left, rect.top + rect.height/2],
      [rect.left + rect.width, rect.top + rect.height/2],
      [rect.left, rect.top + rect.height],
      [rect.left + rect.width/2, rect.top + rect.height],
      [rect.left + rect.width, rect.top + rect.height],
    ];
    handles.forEach((h,i)=>{
      h.style.left = (pts[i][0] - 3) + "px";
      h.style.top  = (pts[i][1] - 3) + "px";
    });

    ensureSizeLabel();
    sizeLabel.textContent = Math.round(rect.width) + " × " + Math.round(rect.height);
    sizeLabel.style.left = rect.left + "px";
    sizeLabel.style.top  = (rect.top - 20) + "px";
  }

  function clearFrame(){
    frame && frame.remove();
    frame = null;
    handles.forEach(h => h.remove());
    handles = [];
    if (sizeLabel){ sizeLabel.remove(); sizeLabel = null; }
  }

  function findElement(el){
    let n = el;
    while (n && n !== document.body) {
      const r = n.getBoundingClientRect();
      if (r.width > 16 && r.height > 16) return n;
      n = n.parentElement;
    }
    return el;
  }

  function move(e){
    if (mode !== "element") return;
    const el = findElement(e.target);
    const r = el.getBoundingClientRect();
    createFrame(r);
  }

  function click(e){
    if (mode !== "element") return;
    e.preventDefault();
    e.stopPropagation();

    const el = findElement(e.target);
    const rect = el.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;

    chrome.runtime.sendMessage({ type:"capture-visible" }, async (res) => {
      if (!res || !res.success) {
        clearFrame();
        mode = null;
        document.removeEventListener("mousemove", move, true);
        document.removeEventListener("click", click, true);
        return;
      }

      const img = new Image();
      img.src = res.screenshot;
      await img.decode();

      const canvas = document.createElement("canvas");
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      const ctx = canvas.getContext("2d");

      ctx.drawImage(
        img,
        rect.left * dpr,
        rect.top * dpr,
        rect.width * dpr,
        rect.height * dpr,
        0,0,
        rect.width * dpr,
        rect.height * dpr
      );

      chrome.runtime.sendMessage({
        type:"save-image",
        fileName:"element-" + Date.now() + ".png",
        dataUrl:canvas.toDataURL("image/png")
      });

      clearFrame();
      mode = null;
      document.removeEventListener("mousemove", move, true);
      document.removeEventListener("click", click, true);
    });
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "capture-element") {
      mode = "element";
      document.addEventListener("mousemove", move, true);
      document.addEventListener("click", click, true);
    }
  });

})();