document.addEventListener("DOMContentLoaded", () => {

  function send(msg){
    chrome.tabs.query({active:true,currentWindow:true}, tabs => {
      if (!tabs || !tabs[0]) return;
      const tabId = tabs[0].id;

      chrome.tabs.sendMessage(tabId, {type:"ping"}, resp => {
        if (chrome.runtime.lastError || !resp) {
          alert("UI Searcher доступен только на обычных сайтах (http/https).\nОткрой страницу сайта и попробуй снова.");
          return;
        }
        chrome.tabs.sendMessage(tabId, msg);
        window.close();
      });
    });
  }

  document.getElementById("btnElement").onclick = () => send({type:"capture-element"});
  document.getElementById("btnVisible").onclick = () => send({type:"capture-visible"});
  document.getElementById("btnPage").onclick    = () => send({type:"capture-page"});

  const info = document.getElementById("infoLink");
  info.addEventListener("click", (e) => {
    e.preventDefault();
    alert("UI Searcher\n\nAlt+1 — Capture element\nAlt+2 — Capture visible\nAlt+3 — Capture full page");
  });
});